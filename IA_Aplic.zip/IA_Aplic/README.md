# IA_Aplic — Conciliador de Aplicações Financeiras

Aplicação de página única (sem backend, sem build) que concilia o relatório
TOTVS contra os extratos bancários da Redegazeta, operação a operação, e
calcula o ajuste líquido a lançar no TOTVS.

Reconstrói e substitui um protótipo anterior feito no Google AI Studio,
mantendo a regra de negócio original e adicionando uma segunda conferência
dedicada às aplicações do BTG.

## O que o sistema faz

- **Lado TOTVS**: lê o relatório em CSV/XLS/XLSX (ou texto colado),
  localizando automaticamente o cabeçalho com as colunas "Operação",
  "Sdo Operação" e "C/C Padrão", mesmo com linhas extras antes dele.
- **Aba Banestes**: casa cada operação do TOTVS com o extrato em PDF (ou
  texto) do banco por número de operação. O extrato bancário é tratado como
  fonte da verdade; a diferença vira a instrução de ajuste (somar/subtrair/
  incluir no TOTVS).
- **Aba BTG**: as operações do TOTVS que sobram (não encontradas no extrato
  bancário e não estão na lista de contas ignoradas) são casadas com as
  linhas de "Data Compra" extraídas do extrato de fundos do BTG Pactual,
  usando o Saldo Bruto como chave (o PDF do BTG não tem número de operação
  em comum com o TOTVS). Quando não há PDF do BTG carregado, a aba mostra
  apenas a lista informativa dessas operações. Quando não há match exato,
  o sistema sugere o valor mais próximo encontrado no extrato.
- **Configurações editáveis na tela** (ficam salvas no navegador): nome do
  banco principal e lista de contas do TOTVS a desconsiderar (padrão:
  BANES-TEMP, Banes-PF, BANESAMALF).
- **Exportações**: PDF e Excel por aba, e uma apresentação executiva em
  PowerPoint sobre o próprio sistema.
- Todo o processamento roda no navegador — nenhum arquivo é enviado a um
  servidor.

## Como rodar

Não há passo de build. Basta abrir `index.html` em um navegador, ou
hospedar a pasta em qualquer servidor estático (GitHub Pages, Netlify,
Vercel, um bucket S3, etc.) — é um único arquivo autocontido que carrega
suas bibliotecas (Decimal.js, PapaParse, SheetJS, pdf.js, jsPDF, PptxGenJS)
via CDN.

### Publicar no GitHub Pages

```bash
git push -u origin main
```

Depois, em Settings → Pages do repositório, aponte para a branch `main` e
a pasta raiz.

## Estrutura

```
index.html   — aplicação inteira (HTML + CSS + JS)
README.md    — este arquivo
```

## Histórico

Este projeto substitui o protótipo original gerado no Google AI Studio
(React + Vite + TypeScript + servidor Express). As principais mudanças em
relação a ele estão registradas no histórico de commits deste repositório.
